
<html>
<body>


<script type="text/javascript">
Document.write("hello world")
</script>

</body>
</html>